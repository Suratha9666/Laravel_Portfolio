<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/portfolio/home', function () {
    return view('portfolio.HomePage');
});


Route::get('/portfolio/recommendation', function () {
    return view('portfolio.Recommendation');
});

Route::get('/portfolio/customers', function () {
    return view('portfolio.Customers');
});

Route::get('/portfolio/skills', 'workController@index');

Route::get('/portfolio/works', 'LatestController@index');

Route::get('/portfolio/hire', 'HireController@index');

Route::get('/portfolio/admin/home', function () {
    return view('portfolio.AdminHome');
});

Route::get('/portfolio/admin/recommendation', function () {
    return view('portfolio.AdminRecommendation');
});

Route::get('/portfolio/admin/customers', function () {
    return view('portfolio.AdminCustomers');
});

Route::resource('/portfolio/admin/hire', 'AdminHireController');

Route::resource('/portfolio/admin/skills', 'AdminWorkController');

Route::resource('/portfolio/admin/works', 'AdminLatestController');

Route::get('/portfolio/login', 'UserController@index');

Route::post('/portfolio/add/works', function () {
    return view('portfolio.AddWork');
});

Route::post('/portfolio/add/education', function () {
    return view('portfolio.AddEducation');
});

Route::resource('/portfolio/admin/edu', 'AdminEducationController');

Route::post('/portfolio/add/image', function () {
    return view('portfolio.AddImage');
});

Route::post('/portfolio/add/hire', function () {
    return view('portfolio.AddHire');
});

Route::resource('/portfolio/add/user', 'UserController');

Route::resource('/portfolio/add/contact', 'ContactController');

Route::resource('/portfolio/login', 'LoginController');

Route::resource('/portfolio/filter/image', 'FilterController');

Route::resource('/portfolio/filter/user', 'UserFilterController');

Route::resource('/portfolio/add/admin/user', 'AdminController');

Route::resource('/portfolio/add/admin/contact', 'AdminContactController');




    










