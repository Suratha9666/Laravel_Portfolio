<!DOCTYPE html>
<html>
<?php echo e(csrf_field()); ?>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>MySkills</title>
	<link rel="stylesheet" type="text/css" href="/css/portfolio.css">
	<script type="text/javascript" src="/js/script.js"></script>
	<script type="text/javascript" src="/js/ValidationScript.js"></script>
</head>
<body id="skills">

	<!-- Header NavBar -->
	<header>
		<nav>
			<h1 align="left">Suratha Pyari BH</h1>
			<div class="topnav-right">
				<a href="http://localhost:8000/portfolio/home">HOME</a>
		  		<a href="http://localhost:8000/portfolio/skills">MY SKILLS</a>
		  		<a href="http://localhost:8000/portfolio/recommendation">RECOMMENDATION</a>
		  		<a href="http://localhost:8000/portfolio/works">WORKS</a>
		  		<a href="http://surathapyari.uta.cloud">BLOG</a>
		  		<a href="http://localhost:8000/portfolio/hire">HIRE ME</a>
		  		<button id="button" onclick="show()">LOG IN</button>
		  		<button id="button" onclick="popup()">SIGN UP</button>
		  	</div>
		</nav>
	</header>

	<!-- Skills and Expertise Section -->
	<section>
		<p id="skillh1"><strong>SKILLS &<br>EXPERTISE</strong></p>
		<br>
		<p id="skillp">Full-Stack Developer</p>
		<br>
		<figure id="image">
			<img src="/Images/My-Image.jpeg" alt="Suratha" width="250" height="300">
		</figure>
	</section>
	<article class="skills">
		<div class="leftdesc">
			<img src="/Images/Branding-Icon.png" alt="branding-icon" width="50" height="50">
			<h3 class="icon">Branding</h3>
			<p class="paraex">Creating logos and posters for<br>your company.</p>
			<img src="/Images/Design-Icon.png" alt="design-icon" width="50" height="50">
			<h3 class="icon">Design</h3>
			<p class="paraex">Maintaining the quality and<br>productivity in the works to please<br>my clients.</p>
		</div>
		<div class="rightdesc">
			<img src="/Images/Marketing-Icon.png" alt="marketing-icon" width="50" height="50">
			<h3 class="icon">Marketing</h3>
			<p class="para">Trend designs for a better <br>experience of both images, logos<br>and websites.</p>
			<img src="/Images/Programming-Icon.png" alt="programming-icon" width="50" height="50">
			<h3 class="icon">Programming</h3>
			<p class="para">Developing applications and<br>systems that meet the needs and<br>streamline the work and<br>experiences of users.</p>
		</div>
	</article>
	
	<!-- Smart Digital Solutions -->
	<article class="tabo">
		<p id="paranext"><strong id="part">Smart Digital Solutions </strong> A Full-Stack Developer</p>
		<figure align="center" id="smart">
			<img src="/Images/device01.png" alt="device1" width="110" height="110">
			<img src="/Images/device02.png" alt="device2" width="100" height="100">
			<img src="/Images/device03.png" alt="device3" width="100" height="100">
		</figure>
	</article><br><br><br><br><br><br><br><br><br><br><br><br>

	<!-- Work Experience Section -->
	<article id="workexperience">
		<h1 class="leftspc">WORK EXPERIENCE</h1>
		<p class="spc">I want to look back on my career and be proud of the work, <br> and be proud that I tried everything. --Jon Stewart</p>
		
	</article>
	<form name="form1" action="AddWork.php" method="post">
		<button id="buttonx" name="formVar" style="float:right;margin-right:250px;font-size: 17px;padding: 4px;display: none;">ADD WORK EXPERIENCE</button> 
	</form>
    <section id="workexp">
	    <table>
	    	<?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <tr>
	           <td>
	                <article class="workleft" style='margin-left:100px;margin-top:0px;'>
	                	<p class="year" style='width:300px;text-align:right;'><strong><?php echo e($row['from_date']); ?> - <?php echo e($row['to_date']); ?></strong></p><br><br>
					            <h2 style='width:200px;text-align:right;'><strong><?php echo e($row['organization']); ?></strong></h2><br><br><br><hr class="workhr"><br><br><br>
				    </article>
		           		</td>
		           		<td>
		               <div class="workright1" style='margin-left:100px;margin-top:-100px;'>
	    			        
	    			        <p ><?php echo e($row['role']); ?><br /><br/><?php echo e($row['description']); ?> </p>
	    			       	<form name="form2" action="EditWork.php?id=<?php echo e($row['id']); ?>" method="post">
	    			        	<button name="edit" style="margin-left:60px;font-size: 17px;padding: 4px;display: none;">EDIT</button>
	    			        </form>
	    			        <br>
	    			        <form name="form3" action="DeleteWork.php?id=<?php echo e($row['id']); ?>" method="post">
								<button disabled onclick="alert('Are you sure you want to delete this record?')" style="margin-left:60px;font-size: 17px;padding: 4px;display: none;">DELETE</button><br><br><br>
							</form>
			     		</div>
	           </td>
	       </tr>
	       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	   </table>
	</section>

	<!-- Education Section -->
	<article id="education">
		<h1 class="leftspc">EDUCATION</h1>
		<p class="spc1">I want to look back on my career and be proud of the work, <br> and be proud that I tried everything. --Jon Stewart</p>
	</article>
	<form name="form4" action="AddEducation.php" method="post">
		<button name="addedu" style="float:right;margin-right:250px;font-size: 17px;padding: 4px;display: none;">ADD EDUCATION</button> <br><br>
	</form>
    <section id="education">
	    <table>
	    	<?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <tr>
	           <td>
	                <article class="eduleft" style='margin-left:100px;margin-top:0px;'>
		                <p class="year" style='width:300px;text-align:right;'><strong><?php echo e($row['start_date']); ?> - <?php echo e($row['end_date']); ?></strong></p><br><br>
			            <h2 style='width:200px;text-align:right;'><strong style='text-align:right;'><?php echo e($row['degree_name']); ?></strong></h2><br><br><br><hr class="workhr"><br><br><br>
		            </article>
	           </td>
	           <td>
	               <div class="eduright1" style='margin-left:800px;margin-top:-70px;width:400px;'>
    			      	<p ><?php echo e($row['field_of_study']); ?><br /><br/><?php echo e($row['university']); ?> </p>
    			       	<form name="form5" action="EditEducation.php?id=<?php echo e($row['id']); ?>" method="post">
    			        	<button name="edit" style="margin-left:60px;font-size: 17px;padding: 4px;display: none;">EDIT</button>
    			        </form>
    			        <br>
    			        <form name="form6" action="DeleteEducation.php?id=<?php echo e($row['id']); ?>" method="post">
							<button onclick="alert('Are you sure you want to delete this record?')" style="margin-left:60px;font-size: 17px;padding: 4px;display: none;">DELETE</button><br><br><br><br><br>
						</form>
    			    </div>
	           </td>
	       </tr>
	       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	   </table>
	</section>
	
	<!-- Footer NavBar -->
	<footer id="skillfooter">
		<nav>
			<div class="bottomnav-left">
				<a href="http://localhost:8000/portfolio/home">HOME</a>
		  		<a href="http://localhost:8000/portfolio/skills">MY SKILLS</a>
		  		<a href="http://localhost:8000/portfolio/recommendation">RECOMMENDATION</a>
		  		<a href="http://localhost:8000/portfolio/customers">CUSTOMERS</a>
		  		<a href="http://localhost:8000/portfolio/works">WORKS</a>
		  		<button id="btn" onclick="div_show()">CONTACT FORM</button>
		  	</div>
		  	</div>
		  	<div id="footericon">
		  		<img src="/Images/Footer-icons.png" alt="icon" width="150" height="30">
		  	</div>
		 </nav>
	</footer>

	
	<!-- Code for CONTACT FORM popup -->
	<section id="wrapper">
		<div id="contact">
			<div id="popupContact">
				<form action="http://localhost:8000/portfolio/add/contact" id="contactform" method="post" name="contactform" onsubmit="return validateContact()">
					<?php echo e(csrf_field()); ?>

					<h3>Have a project you'd like to discuss?</h3>
					<span onclick="div_hide()" class="close" title="Close Modal">x</span>
					<hr>
					<label for="name">Name</label><br>
					<input id="name" name="name" placeholder="Enter a valid name" type="text" required><br><br>
					<label for="email">Email</label><br>
					<input id="email" name="email" placeholder="Enter a valid email" type="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format. e.g. john_doe@gmail.com"><br><br>
					<label for="message">Message</label>
					<textarea rows="4" cols="50" name="message" words placeholder="Message" required maxlength="200" ></textarea>
					<button id="send" name="send">SEND</button>
				</form>
			</div>
		</div>
	</section>
	<!-- End of CONTACT FORM popup -->
	
	<!-- Code for LOGIN FORM popup -->
	<section id="wrapper">
		<div id="login">
			<div id="popupLogin">
				<form action="http://localhost:8000/portfolio/login" id="loginform" method="post" name="loginform" onsubmit="return validateLogin()">
					<?php echo e(csrf_field()); ?>

					<h3>Log in</h3>
					<span onclick="hide()" class="hide" title="Close Modal">x</span>
					<hr>
					<label for="name">User:</label><br>
					<input id="name" name="name" placeholder="Enter a valid username" type="text" required><br><br>
					<label for="password">Password:</label><br>
					<input id="password" name="password" placeholder="Enter a valid password" type="password" required ><br><br>
					<hr>
					<div id="buttonzone">
						<button id="close" onclick="hide()">CLOSE</button>
						<button id="save" name="getin">GET IN</button>
					</div>
				</form>
			</div>
		</div>
	</section>
	<!-- End of LOGIN FORM popup -->

	<!-- Code for SIGNUP FORM popup -->
	<section id="wrapper">
		<div id="signup">
			<div id="popupSignup">
				<form action="http://localhost:8000/portfolio/add/user" id="signupform" method="post" name="signupform" onsubmit="return validateSignup()">
					<?php echo e(csrf_field()); ?>

					<h3>check in</h3>
					<span onclick="popout()" class="popout" title="Close Modal">x</span>
					<hr>
					<label for="name">Name:</label><br>
					<input id="name" name="name" placeholder="Enter a valid name" type="text" required><br><br>
					<label for="lastname">Last name:</label><br>
					<input id="lastname" name="lastname" placeholder="Enter valid Last name" type="text" required><br><br>
					<label for="email">Email:</label><br>
					<input id="email" name="email" placeholder="Enter a valid email" type="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format. e.g. john_doe@gmail.com"><br><br>
					<label for="user">User:</label><br>
					<input id="user" name="user" placeholder="Enter a valid user name" type="text" required minlength="8" maxlength="16"><br><br>
					<label for="password">Password:</label><br>
					<input id="password" name="password" placeholder="Enter a valid password" type="password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" onchange="form.repeatpassword.pattern = RegExp.escape(this.value);" title="Password must contain at least 6 characters, including UPPER/lowercase and numbers"><br><br>
					<label for="password">Repeat password:</label><br>
					<input id="repeatpassword" name="repeatpassword" placeholder="Enter matching password" type="password" required><br><br>
					<hr>
					<div id="buttonzone">
						<button id="close" onclick="popout()">CLOSE</button>
						<button id="save" name="save">SAVE</button>
					</div>
				</form>
			</div>
		</div>
	</section>
    <!-- End of SIGNUP FORM popup -->


    

</body>
</html><?php /**PATH /Users/surathapyari/Desktop/bhupathiraju_project5/resources/views/portfolio/MySkills.blade.php ENDPATH**/ ?>