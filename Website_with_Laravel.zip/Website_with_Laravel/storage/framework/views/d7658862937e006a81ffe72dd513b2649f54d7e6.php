
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Insert New Work</title>
</head>
<body style="background-color:black;color:white;">
<div class="form">
<div>
<h1>Insert New Work</h1>
<form name="form" method="post" action="<?php echo e(url('portfolio/admin/works')); ?>" enctype="multipart/form-data"> 
<?php echo e(csrf_field()); ?> 
<input type="hidden" name="new" value="1" />
<label for="caption">Caption:</label><br>
<p><input type="text" id ="caption" name="caption" placeholder="Enter the Caption" style="height:20px;width:500px;" required /></p>
<label for="category">Category:</label><br>
<p><input type="text" id="category" name="category" placeholder="Enter the Category" style="height:20px;width:500px;" required /></p>
<label for="image">Image:</label><br>
<p><input type="file" id="image" name="image" style="height:20px;width:500px;" required /></p><br>
<p><input name="submit" type="submit" value="Submit" style="width:100px;color:blue;font-size:1000px;" /></p>
</form>
</div>
</div>
</body>
</html><?php /**PATH /Users/surathapyari/Desktop/bhupathiraju_project5/resources/views/portfolio/AddImage.blade.php ENDPATH**/ ?>