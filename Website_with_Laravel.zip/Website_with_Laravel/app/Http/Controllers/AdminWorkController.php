<?php

namespace App\Http\Controllers;
use App\Experience;
use App\Education;
use Illuminate\Http\Request;

class AdminWorkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $works = Experience::all()-> toArray();
        $educations = Education::all()-> toArray();
        return view('portfolio.AdminSkills',compact('works','educations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('portfolio.AddWork');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([          
            'start' => 'required',          
            'end'=> 'required',
            'organization'=> 'required',
            'role'=> 'required',
            'description'=> 'required',
        ]);         
        $experiences= new experience();        
        $experiences->from_date=$request->get('start');        
        $experiences->to_date=$request->get('end');  
        $experiences->role=$request->get('role'); 
        $experiences->organization=$request->get('organization');
        $experiences->description=$request->get('description');      
        $experiences->save();        
        return redirect('portfolio/admin/skills');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $experiences = Experience::find($id);        
        return view('portfolio.EditWork',compact('experiences','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([          
            'start' => 'required',          
            'end'=> 'required',
            'organization'=> 'required',
            'role'=> 'required',
            'description'=> 'required',       
        ]);         
        $experiences = Experience::find($id);        
        $experiences->from_date=$request->get('start');        
        $experiences->to_date=$request->get('end');  
        $experiences->role=$request->get('role'); 
        $experiences->organization=$request->get('organization');
        $experiences->description=$request->get('description');      
        $experiences->save();        
        return redirect('portfolio/admin/skills');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $experiences = Experience::find($id);         
        $experiences->delete();        
        return redirect('portfolio/admin/skills');
    }
}
