<?php

namespace App\Http\Controllers;
use App\Works;
use Illuminate\Http\Request;

class AdminLatestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $latest = Works::all()-> toArray();
        return view('portfolio.AdminWorks',compact('latest'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([          
            'caption' => 'required',          
            'category'=> 'required',
            'image'=> 'required',
        ]); 

        $img = $request->file('image');
        $name = time().'.'.$img->getClientOriginalExtension();
        $destinationPath = public_path('/Images');
        $img->move($destinationPath, $name);
        
        $latest= new works();        
        $latest->image="/Images/{$name}";
        $latest->caption=$request->get('caption');  
        $latest->category=$request->get('category'); 
        $latest->save();        
        return redirect('portfolio/admin/works');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $latest = Works::find($id);        
        return view('portfolio.EditImage',compact('latest','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([          
            'caption' => 'required',          
            'category'=> 'required',
            'image'=> 'required',
            
        ]); 
        $img = $request->file('image');
        $name = time().'.'.$img->getClientOriginalExtension();
        $destinationPath = public_path('/Images');
        $img->move($destinationPath, $name); 
               
        $latest= Works::find($id);       
        $latest->image="/Images/{$name}";       
        $latest->caption=$request->get('caption');  
        $latest->category=$request->get('category'); 
        $latest->save();        
        return redirect('portfolio/admin/works');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $latest= Works::find($id);         
        $latest->delete();        
        return redirect('portfolio/admin/works');
    }
}
