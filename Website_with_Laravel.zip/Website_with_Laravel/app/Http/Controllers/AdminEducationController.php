<?php

namespace App\Http\Controllers;
use App\Education;
use Illuminate\Http\Request;

class AdminEducationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([          
            'from' => 'required',          
            'to'=> 'required',
            'degree'=> 'required',
            'field'=> 'required',
            'university'=> 'required',
        ]);         
        $education= new education();        
        $education->start_date=$request->get('from');        
        $education->end_date=$request->get('to');  
        $education->degree_name=$request->get('degree'); 
        $education->field_of_study=$request->get('field');
        $education->university=$request->get('university');      
        $education->save();        
        return redirect('portfolio/admin/skills');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $education = Education::find($id);        
        return view('portfolio.EditEducation',compact('education','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([          
            'from' => 'required',          
            'to'=> 'required',
            'degree'=> 'required',
            'field'=> 'required',
            'university'=> 'required',      
        ]);         
        $education = Education::find($id);         
        $education->start_date=$request->get('from');        
        $education->end_date=$request->get('to');  
        $education->degree_name=$request->get('degree'); 
        $education->field_of_study=$request->get('field');
        $education->university=$request->get('university');       
        $education->save();        
        return redirect('portfolio/admin/skills');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $education = Education::find($id);        
        $education->delete();        
        return redirect('portfolio/admin/skills');
    }
}
