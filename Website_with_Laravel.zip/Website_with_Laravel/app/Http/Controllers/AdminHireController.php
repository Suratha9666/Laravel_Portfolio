<?php

namespace App\Http\Controllers;
use App\Hire;
use Illuminate\Http\Request;

class AdminHireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hire = Hire::all()-> toArray();
        return view('portfolio.AdminHire',compact('hire'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([          
            'price' => 'required',          
            'purpose'=> 'required',
            'image'=> 'required',
            'ability'=> 'required',
            
        ]);
        $img = $request->file('image');
        $name = time().'.'.$img->getClientOriginalExtension();
        $destinationPath = public_path('/Images');
        $img->move($destinationPath, $name);         
        
        $hire= new hire();        
        $hire->hire_image="/Images/{$name}";       
        $hire->hire_price=$request->get('price');  
        $hire->purpose=$request->get('purpose'); 
        $hire->included_ability=$request->get('ability'); 
        $hire->save();        
        return redirect('portfolio/admin/hire');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hire = Hire::find($id);        
        return view('portfolio.EditHire',compact('hire','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([          
            'price' => 'required',          
            'purpose'=> 'required',
            'image'=> 'required',
            'ability'=> 'required',
            
        ]); 
        $img = $request->file('image');
        $name = time().'.'.$img->getClientOriginalExtension();
        $destinationPath = public_path('/Images');
        $img->move($destinationPath, $name);          
        
        $hire= Hire::find($id);       
        $hire->hire_image="/Images/{$name}";        
        $hire->hire_price=$request->get('price');  
        $hire->purpose=$request->get('purpose'); 
        $hire->included_ability=$request->get('ability'); 
        $hire->save();        
        return redirect('portfolio/admin/hire');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hire= Hire::find($id);
        $hire->delete(); 
        return redirect('portfolio/admin/hire');
    }
}
