<!DOCTYPE html>
<html>
{{ csrf_field() }}
<head>
	<title>Works</title>
	<link rel="stylesheet" type="text/css" href="/css/portfolio.css">
	<script type="text/javascript" src="/js/script.js"></script>
	<script type="text/javascript" src="/js/ValidationScript.js"></script>
</head>
<body id="works">

	<!-- Header NavBar -->
	<header>
		<nav>
			<h1 align="left">Suratha Pyari BH</h1>
			<div class="topnav-right">
				<a href="http://localhost:8000/portfolio/admin/home">HOME</a>
		  		<a href="http://localhost:8000/portfolio/admin/skills">MY SKILLS</a>
		  		<a href="http://localhost:8000/portfolio/admin/recommendation">RECOMMENDATION</a>
		  		<a href="http://localhost:8000/portfolio/admin/works">WORKS</a>
		  		<a href="http://surathapyari.uta.cloud">BLOG</a>
		  		<a href="http://localhost:8000/portfolio/admin/hire">HIRE ME</a>
		  		<button id="button" onclick="show()">LOG IN</button>
		  		<button id="button" onclick="popup()">SIGN UP</button>
		  	</div>
		</nav>
	</header>
	<!-- Showing Works Section -->
	<section>
		<h1 class="leftspc">MY LATEST WORK</h1>
		<p class="spc">I want to look back on my career and be proud of the work, <br> and be proud that I tried everything. --Jon Stewart</p>
	</section>
	<form method="post" name="myform" action="{{url('portfolio/filter/image')}}" style="display:none;">
		{{csrf_field()}} 
		<input type="hidden" name="formVar" value="">
		<input type="submit" value="Send form!">
	</form>
	<div id="myDiv">
    	<button  onclick="document.myform.formVar.value='all'; document.myform.submit(); return false" style="padding:5px;margin-right:2px;margin-left:50px;">SHOW ALL</button>
    	<button  onclick="document.myform.formVar.value='websites'; document.myform.submit(); return false" style="padding:5px;margin-right:2px;margin-left:50px;">WEBSITES</button>
    	<button  onclick="document.myform.formVar.value='apps'; document.myform.submit(); return false" style="padding:5px;margin-right:2px;margin-left:50px;">APPS</button>
        <button  onclick="document.myform.formVar.value='design'; document.myform.submit(); return false" style="padding:5px;margin-right:2px;margin-left:50px;">DESIGN</button>
        <button  onclick="document.myform.formVar.value='photography'; document.myform.submit(); return false" style="padding:5px;margin-right:2px;margin-left:50px;">PHOTOGRAPHY</button>
    </div>
    
    
    <!-- Work Images Section -->
	<br><br>
	<form name="form10" action="http://localhost:8000/portfolio/add/image" method="post">
		{{csrf_field()}} 
		<button onclick=""style="margin-left:100px;font-size: 17px;padding: 4px;">ADD LATEST WORK</button><br><br><br>
	</form>
	<div class="portfolioContainer">
		@foreach($latest as $row)
	    <div class="img1">
            <img class="websites" src="{{$row['image']}}" alt="images" width="150" height="200" style="margin-right:25px; margin-left:70px;margin-top:50px;"> 
            <p  style="float:right;margin-left:40px;margin-top:-200px;">{{$row['caption']}}<br /><br/>{{$row['category']}}</p><br>
            <form class="forms" name="form11" style="margin-top:-140px;margin-left:280px;" action="{{action('AdminLatestController@edit', $row['id'])}}">
   		        <br><br><button onclick="" style="font-size: 14px;padding: 4px;">EDIT</button><br><br>
   	        </form>
   	        <form class="forms" name="form12" style="margin-top:-50px;margin-left:-50px;" action="{{action('AdminLatestController@destroy', $row['id'])}}" method="post">
   	        	{{csrf_field()}} 
    			        	<input name="_method" type="hidden" value="DELETE">  
		        <button onclick="alert('Are you sure you want to delete this record?')" style="font-size: 14px;padding: 4px;">DELETE</button>
	         </form>
          </div>
          @endforeach
	</div>

	<!-- Footer NavBar -->
	<footer id="workfooter">
		<nav>
			<div class="bottomnav-left">
				<a href="http://localhost:8000/portfolio/admin/home">HOME</a>
		  		<a href="http://localhost:8000/portfolio/admin/skills">MY SKILLS</a>
		  		<a href="http://localhost:8000/portfolio/admin/recommendation">RECOMMENDATION</a>
		  		<a href="http://localhost:8000/portfolio/admin/customers">CUSTOMERS</a>
		  		<a href="http://localhost:8000/portfolio/admin/works">WORKS</a>
		  		<button id="btn" onclick="div_show()">CONTACT FORM</button>
		  	</div>
		  	</div>
		  	<div id="footericon">
		  		<img src="/Images/Footer-icons.png" alt="icon" width="150" height="30">
		  	</div>
		 </nav>
	</footer>


	<!-- Code for CONTACT FORM popup -->
	<section id="wrapper">
		<div id="contact">
			<div id="popupContact">
				<form action="http://localhost:8000/portfolio/add/admin/contact" id="contactform" method="post" name="contactform" onsubmit="return validateContact()">
					{{ csrf_field() }}
					<h3>Have a project you'd like to discuss?</h3>
					<span onclick="div_hide()" class="close" title="Close Modal">x</span>
					<hr>
					<label for="name">Name</label><br>
					<input id="name" name="name" placeholder="Enter a valid name" type="text" required><br><br>
					<label for="email">Email</label><br>
					<input id="email" name="email" placeholder="Enter a valid email" type="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format. e.g. john_doe@gmail.com"><br><br>
					<label for="message">Message</label>
					<textarea rows="4" cols="50" name="message" words placeholder="Message" required maxlength="200" ></textarea>
					<button id="send" name="send">SEND</button>
				</form>
			</div>
		</div>
	</section>
	<!-- End of CONTACT FORM popup -->
	
	<!-- Code for LOGIN FORM popup -->
	<section id="wrapper">
		<div id="login">
			<div id="popupLogin">
				<form action="http://localhost:8000/portfolio/login" id="loginform" method="post" name="loginform" onsubmit="return validateLogin()">
					{{ csrf_field() }}
					<h3>Log in</h3>
					<span onclick="hide()" class="hide" title="Close Modal">x</span>
					<hr>
					<label for="name">User:</label><br>
					<input id="name" name="name" placeholder="Enter a valid username" type="text" required><br><br>
					<label for="password">Password:</label><br>
					<input id="password" name="password" placeholder="Enter a valid password" type="password" required ><br><br>
					<hr>
					<div id="buttonzone">
						<button id="close" onclick="hide()">CLOSE</button>
						<button id="save" name="getin">GET IN</button>
					</div>
				</form>
			</div>
		</div>
	</section>
	<!-- End of LOGIN FORM popup -->

	<!-- Code for SIGNUP FORM popup -->
	<section id="wrapper">
		<div id="signup">
			<div id="popupSignup">
				<form action="http://localhost:8000/portfolio/add/admin/user" id="signupform" method="post" name="signupform" onsubmit="return validateSignup()">
					{{ csrf_field() }}
					<h3>check in</h3>
					<span onclick="popout()" class="popout" title="Close Modal">x</span>
					<hr>
					<label for="name">Name:</label><br>
					<input id="name" name="name" placeholder="Enter a valid name" type="text" required><br><br>
					<label for="lastname">Last name:</label><br>
					<input id="lastname" name="lastname" placeholder="Enter valid Last name" type="text" required><br><br>
					<label for="email">Email:</label><br>
					<input id="email" name="email" placeholder="Enter a valid email" type="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Email should be in valid format. e.g. john_doe@gmail.com"><br><br>
					<label for="user">User:</label><br>
					<input id="user" name="user" placeholder="Enter a valid user name" type="text" required minlength="8" maxlength="16"><br><br>
					<label for="password">Password:</label><br>
					<input id="password" name="password" placeholder="Enter a valid password" type="password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" onchange="form.repeatpassword.pattern = RegExp.escape(this.value);" title="Password must contain at least 6 characters, including UPPER/lowercase and numbers"><br><br>
					<label for="password">Repeat password:</label><br>
					<input id="repeatpassword" name="repeatpassword" placeholder="Enter matching password" type="password" required><br><br>
					<hr>
					<div id="buttonzone">
						<button id="close" onclick="popout()">CLOSE</button>
						<button id="save" name="save">SAVE</button>
					</div>
				</form>
			</div>
		</div>
	</section>
    <!-- End of SIGNUP FORM popup -->
    

</body>
</html>