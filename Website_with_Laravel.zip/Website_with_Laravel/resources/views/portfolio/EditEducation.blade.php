
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Update Education</title>
</head>
<body style="background-color:black;color:white;">
<div class="form">
<div>
<h1>Update Education</h1>
<form name="form" method="post" action="{{action('AdminEducationController@update', $id)}}"> 
{{ csrf_field() }}
<input name="_method" type="hidden" value="PATCH">
<input type="hidden" name="new" value="1" />
<label for="start">From date:</label><br>
<p><input type="text" id ="from" name="from" value="{{$education->start_date}}" placeholder="Enter From date in the format YYYY(Mon)" style="height:20px;width:500px;" required /></p>
<label for="end">To date:</label><br>
<p><input type="text" id="to" name="to" value="{{$education->end_date}}" placeholder="Enter To date in the format YYYY(Mon) or PRESENT" style="height:20px;width:500px;" required /></p>
<label for="organization">Degree:</label><br>
<p><input type="text" id="degree" name="degree" value="{{$education->degree_name}}" placeholder="Enter Degree name" style="height:20px;width:500px;" required /></p>
<label for="role">Field of Study:</label><br>
<p><input type="text" id="field" name="field" value="{{$education->field_of_study}}" placeholder="Enter your field of study" style="height:20px;width:500px;" required /></p>
<label for="description">University:</label><br>
<p><input type="text" id="university" name="university" value="{{$education->university}}" placeholder="Enter University name" style="height:20px;width:500px;" required /></p><br>
<p><input name="submit" type="submit" value="Submit" style="width:100px;color:blue;font-size:1000px;" /></p>
</form>
</div>
</div>
</body>
</html>