
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Update Hire</title>
</head>
<body style="background-color:black;color:white;">
<div class="form">
<div>
<h1>Update Hire</h1>
<form name="form" method="post" action="{{action('AdminHireController@update', $id)}}" enctype="multipart/form-data">
{{ csrf_field() }}
<input name="_method" type="hidden" value="PATCH">
<input type="hidden" name="new" value="1" />

<label for="price">Hire Price:</label><br>
<p><input type="text" id ="price" name="price" value="{{$hire->hire_price}}" placeholder="Enter the Hire Price" style="height:20px;width:500px;" required /></p>
<label for="purpose">Purpose:</label><br>
<p><input type="text" id="purpose" name="purpose" value="{{$hire->purpose}}" placeholder="Enter the Purpose" style="height:20px;width:500px;" required /></p>
<label for="ability">Included Abilities:</label><br>
<p><input type="text" id="ability" name="ability" value="{{$hire->included_ability}}" placeholder="Enter included abilities separated by commas without spaces" style="height:20px;width:500px;" required /></p>
<label for="image">Image:</label><br>
<img src="{{$hire->hire_image}}" alt="cart" width="230" height="170"><br><br>
<input type="file" id="image" name="image"/><br>
<br><br>
<p><input name="submit" type="submit" value="Submit" style="width:100px;color:blue;font-size:1000px;" /></p>
</form>

</div>
</div>
</body>
</html>